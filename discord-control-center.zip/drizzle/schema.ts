import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** One encrypted bot token per authenticated administrator. */
export const botConnections = mysqlTable("bot_connections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tokenEncrypted: text("tokenEncrypted").notNull(),
  botUserId: varchar("botUserId", { length: 64 }).notNull(),
  botUsername: varchar("botUsername", { length: 128 }).notNull(),
  botAvatar: varchar("botAvatar", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Server-side audit trail; secrets and message bodies are never recorded here. */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 80 }).notNull(),
  resourceType: varchar("resourceType", { length: 40 }).notNull(),
  resourceId: varchar("resourceId", { length: 100 }),
  summary: varchar("summary", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type BotConnection = typeof botConnections.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
