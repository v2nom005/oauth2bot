import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import {
  Activity, AlertTriangle, ChevronDown, Hash, LockKeyhole, MessageSquare, Plus, RefreshCw, Send, Server, Shield, Trash2, Users, Webhook, Zap,
} from "lucide-react";

const sectionMeta: Record<string, { eyebrow: string; title: string; description: string; icon: typeof Activity }> = {
  overview: { eyebrow: "CONTROL PLANE", title: "봇 상태와 서버 개요", description: "연결 상태를 확인하고 관리할 서버를 선택하세요.", icon: Activity },
  channels: { eyebrow: "CHANNEL MANAGER", title: "채널 매니저", description: "텍스트·공지·포럼 채널을 조회하고 새 채널을 만들 수 있습니다.", icon: Hash },
  members: { eyebrow: "MEMBER MANAGER", title: "멤버 매니저", description: "서버 멤버와 닉네임, 역할 상태를 확인합니다.", icon: Users },
  roles: { eyebrow: "ROLE CONTROL", title: "역할 관리", description: "역할을 생성하고 봇이 관리할 수 있는 역할을 정리합니다.", icon: Shield },
  messages: { eyebrow: "MESSAGE STUDIO", title: "메시지 · 임베드", description: "채널을 선택해 일반 메시지 또는 임베드를 전송합니다.", icon: MessageSquare },
  webhooks: { eyebrow: "WEBHOOKS", title: "웹훅 관리", description: "채널별 웹훅을 만들고 정리합니다.", icon: Webhook },
  dm: { eyebrow: "DIRECT MESSAGE", title: "DM 보내기", description: "Discord 사용자 ID를 대상으로 봇 DM을 전송합니다.", icon: Send },
  audit: { eyebrow: "AUDIT TRAIL", title: "감사 로그", description: "이 대시보드에서 실행한 관리자 작업을 확인합니다.", icon: Activity },
};

function getSection(location: string) {
  const value = location.replace(/^\//, "");
  return value && sectionMeta[value] ? value : "overview";
}

function errorText(error: unknown) {
  return error instanceof Error ? error.message : "요청을 처리하지 못했습니다.";
}

function formatDate(value: string | Date | undefined) {
  if (!value) return "-";
  return new Date(value).toLocaleString("ko-KR", { dateStyle: "medium", timeStyle: "short" });
}

function colorHex(color: number) {
  return `#${color.toString(16).padStart(6, "0")}`;
}

function SectionHeader({ section, connected }: { section: string; connected: boolean }) {
  const meta = sectionMeta[section] || sectionMeta.overview;
  const Icon = meta.icon;
  return (
    <div className="flex flex-col gap-5 border-b border-white/10 pb-7 md:flex-row md:items-end md:justify-between">
      <div>
        <div className="mb-3 flex items-center gap-2 text-[11px] font-semibold tracking-[0.24em] text-violet-300">
          <Icon className="h-3.5 w-3.5" /> {meta.eyebrow}
        </div>
        <h1 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">{meta.title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">{meta.description}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <a href="https://discord.gg/TeVdHYybvb" target="_blank" rel="noreferrer" className="inline-flex h-9 items-center gap-2 rounded-md border border-white/10 bg-white/[0.04] px-3 text-xs font-medium text-slate-300 transition hover:border-violet-300/30 hover:bg-violet-400/10 hover:text-violet-200"><Server className="h-3.5 w-3.5" /> Venom 서버 가기</a>
        <a href="/api/auth/discord/install" className="inline-flex h-9 items-center gap-2 rounded-md bg-violet-500 px-3 text-xs font-medium text-white transition hover:bg-violet-400"><Zap className="h-3.5 w-3.5" /> Discord로 봇 설치</a>
        <Badge className={connected ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-300" : "border-amber-400/20 bg-amber-400/10 text-amber-200"}>
          <span className={`mr-2 h-1.5 w-1.5 rounded-full ${connected ? "bg-emerald-300" : "bg-amber-300"}`} />
          {connected ? "BOT ONLINE" : "NOT CONNECTED"}
        </Badge>
      </div>
    </div>
  );
}

function SelectBox({ value, onChange, children, disabled = false }: { value: string; onChange: (value: string) => void; children: React.ReactNode; disabled?: boolean }) {
  return (
    <div className="relative">
      <select value={value} onChange={(event) => onChange(event.target.value)} disabled={disabled} className="h-10 w-full appearance-none rounded-md border border-white/10 bg-white/[0.04] px-3 pr-9 text-sm text-slate-200 outline-none transition focus:border-violet-400/70 disabled:cursor-not-allowed disabled:opacity-50">
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-3 h-4 w-4 text-slate-500" />
    </div>
  );
}

function ConnectCard({ status, onConnected }: { status: { connected: boolean; botUsername?: string; botUserId?: string; updatedAt?: Date }; onConnected: () => void }) {
  const [token, setToken] = useState("");
  const connect = trpc.discord.connect.useMutation({
    onSuccess: (data) => { setToken(""); onConnected(); toast.success(`${data.botUsername} 봇이 연결되었습니다.`); },
    onError: (error) => toast.error(errorText(error)),
  });
  const disconnect = trpc.discord.disconnect.useMutation({
    onSuccess: () => { onConnected(); toast.success("봇 연결을 해제했습니다."); },
    onError: (error) => toast.error(errorText(error)),
  });
  return (
    <Card className="overflow-hidden border-violet-400/20 bg-gradient-to-br from-violet-500/[0.13] via-slate-900/70 to-slate-950/80 shadow-2xl shadow-violet-950/20">
      <CardContent className="p-6 md:p-7">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-violet-300/20 bg-violet-400/10 text-violet-200"><LockKeyhole className="h-5 w-5" /></div>
            <div>
              <div className="flex flex-wrap items-center gap-2"><h2 className="text-lg font-semibold text-white">봇 연결</h2>{status.connected && <Badge className="border-emerald-400/20 bg-emerald-400/10 text-emerald-200">{status.botUsername}</Badge>}</div>
              <p className="mt-1 max-w-xl text-sm leading-6 text-slate-400">토큰은 브라우저에 저장하지 않고 서버에서만 암호화 보관합니다. OAuth2 봇 설치와 Bot Token 인증은 Discord 정책상 별도 단계입니다.</p>
              {status.connected && <p className="mt-2 text-xs text-slate-500">Bot ID {status.botUserId} · 마지막 갱신 {formatDate(status.updatedAt)}</p>}
            </div>
          </div>
          <div className="flex w-full flex-col gap-2 sm:flex-row lg:max-w-xl">
            <Input type="password" value={token} onChange={(event) => setToken(event.target.value)} placeholder={status.connected ? "새 토큰으로 교체" : "Discord Bot Token 붙여넣기"} autoComplete="off" className="border-white/10 bg-black/20 text-white placeholder:text-slate-600" />
            <Button disabled={!token.trim() || connect.isPending} onClick={() => connect.mutate({ token })} className="bg-violet-500 text-white hover:bg-violet-400">{connect.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}{status.connected ? "토큰 교체" : "연결 테스트"}</Button>
            {status.connected && <Button variant="outline" disabled={disconnect.isPending} onClick={() => disconnect.mutate()} className="border-white/10 bg-transparent text-slate-300 hover:bg-white/10">해제</Button>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function GuildPicker({ guilds, value, onChange }: { guilds: Array<{ id: string; name: string; icon?: string | null }>; value: string; onChange: (value: string) => void }) {
  return <SelectBox value={value} onChange={onChange} disabled={!guilds.length}><option value="">서버 선택</option>{guilds.map((guild) => <option key={guild.id} value={guild.id}>{guild.name}</option>)}</SelectBox>;
}

function Overview({ guilds, selectedGuildId, setSelectedGuildId, connected, onRefresh }: { guilds: Array<{ id: string; name: string; icon?: string | null }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; connected: boolean; onRefresh: () => void }) {
  return (
    <div className="space-y-5">
      <ConnectCard status={{ connected }} onConnected={onRefresh} />
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard icon={Server} label="접속 서버" value={connected ? String(guilds.length) : "—"} accent="violet" />
        <StatCard icon={Users} label="선택한 서버" value={selectedGuildId ? (guilds.find((guild) => guild.id === selectedGuildId)?.name || "선택됨") : "없음"} accent="cyan" compact />
        <StatCard icon={Shield} label="API 방식" value="권한 인식 REST" accent="emerald" compact />
      </div>
      <Card className="border-white/10 bg-white/[0.035]">
        <CardHeader className="flex-row items-center justify-between space-y-0"><div><CardTitle className="text-base text-white">관리 대상 서버</CardTitle><p className="mt-1 text-sm text-slate-500">봇이 설치되어 있고 토큰에 접근 권한이 있는 서버입니다.</p></div><Button variant="outline" size="sm" onClick={onRefresh} className="border-white/10 bg-transparent text-slate-300 hover:bg-white/10"><RefreshCw className="mr-2 h-4 w-4" /> 새로고침</Button></CardHeader>
        <CardContent><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{guilds.map((guild) => <button key={guild.id} onClick={() => setSelectedGuildId(guild.id)} className={`group flex items-center gap-3 rounded-xl border p-4 text-left transition ${selectedGuildId === guild.id ? "border-violet-400/50 bg-violet-400/10" : "border-white/10 bg-black/10 hover:border-white/20 hover:bg-white/[0.04]"}`}><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 text-sm font-semibold text-slate-300">{guild.name.slice(0, 2).toUpperCase()}</div><div className="min-w-0"><p className="truncate text-sm font-medium text-slate-100">{guild.name}</p><p className="mt-1 text-xs text-slate-500">{guild.id}</p></div><ChevronDown className="ml-auto h-4 w-4 -rotate-90 text-slate-600 group-hover:text-violet-300" /></button>)}{connected && guilds.length === 0 && <EmptyState text="봇이 설치된 서버가 없습니다." />}</div></CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent, compact = false }: { icon: typeof Server; label: string; value: string; accent: "violet" | "cyan" | "emerald"; compact?: boolean }) {
  const color = { violet: "text-violet-300 bg-violet-400/10", cyan: "text-cyan-300 bg-cyan-400/10", emerald: "text-emerald-300 bg-emerald-400/10" }[accent];
  return <Card className="border-white/10 bg-white/[0.035]"><CardContent className="p-5"><div className={`mb-4 flex h-9 w-9 items-center justify-center rounded-lg ${color}`}><Icon className="h-4 w-4" /></div><p className="text-xs uppercase tracking-[0.12em] text-slate-500">{label}</p><p className={`mt-2 font-semibold text-white ${compact ? "truncate text-base" : "text-2xl"}`}>{value}</p></CardContent></Card>;
}

function ResourceShell({ children, guilds, selectedGuildId, setSelectedGuildId, showGuild = true }: { children: React.ReactNode; guilds: Array<{ id: string; name: string; icon?: string | null }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; showGuild?: boolean }) {
  return <div className="space-y-5">{showGuild && <Card className="border-white/10 bg-white/[0.035]"><CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center"><div className="flex items-center gap-2 text-sm font-medium text-slate-300"><Server className="h-4 w-4 text-violet-300" />관리 서버</div><div className="w-full sm:max-w-sm"><GuildPicker guilds={guilds} value={selectedGuildId} onChange={setSelectedGuildId} /></div></CardContent></Card>}{children}</div>;
}

function EmptyState({ text }: { text: string }) { return <div className="col-span-full flex min-h-32 items-center justify-center rounded-xl border border-dashed border-white/10 p-6 text-sm text-slate-500">{text}</div>; }

function ChannelsSection({ guilds, selectedGuildId, setSelectedGuildId, channels, refresh }: { guilds: Array<{ id: string; name: string }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; channels: Array<{ id: string; name: string; type: number; parent_id?: string | null; position: number; topic?: string | null }>; refresh: () => void }) {
  const [name, setName] = useState(""); const [type, setType] = useState("0"); const [topic, setTopic] = useState("");
  const create = trpc.discord.createChannel.useMutation({ onSuccess: () => { setName(""); setTopic(""); refresh(); toast.success("채널을 생성했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  return <ResourceShell guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId}><div className="grid gap-5 xl:grid-cols-[1fr_360px]"><Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">채널 목록 <span className="ml-2 text-xs font-normal text-slate-500">{channels.length}개</span></CardTitle></CardHeader><CardContent className="space-y-2">{channels.map((channel) => <div key={channel.id} className="flex items-center gap-3 rounded-lg border border-white/[0.07] bg-black/10 p-3"><Hash className="h-4 w-4 text-violet-300" /><div className="min-w-0"><p className="truncate text-sm text-slate-200">{channel.name}</p><p className="truncate text-xs text-slate-500">{channel.topic || `type ${channel.type}`} · {channel.id}</p></div><Badge variant="outline" className="ml-auto border-white/10 text-[10px] text-slate-500">{channel.type === 0 ? "TEXT" : channel.type === 5 ? "ANNOUNCEMENT" : `TYPE ${channel.type}`}</Badge></div>)}{selectedGuildId && !channels.length && <EmptyState text="채널이 없습니다." />}</CardContent></Card><Card className="border-violet-400/20 bg-violet-400/[0.04]"><CardHeader><CardTitle className="flex items-center gap-2 text-base text-white"><Plus className="h-4 w-4 text-violet-300" />새 채널</CardTitle></CardHeader><CardContent className="space-y-4"><label className="block text-xs text-slate-400">채널 이름<Input value={name} onChange={(event) => setName(event.target.value)} placeholder="announcements" className="mt-2 border-white/10 bg-black/20 text-white" /></label><label className="block text-xs text-slate-400">채널 유형<SelectBox value={type} onChange={setType}><option value="0">텍스트 채널</option><option value="5">공지 채널</option><option value="15">포럼 채널</option></SelectBox></label><label className="block text-xs text-slate-400">주제 (선택)<Input value={topic} onChange={(event) => setTopic(event.target.value)} placeholder="채널의 목적을 입력하세요" className="mt-2 border-white/10 bg-black/20 text-white" /></label><Button className="w-full bg-violet-500 hover:bg-violet-400" disabled={!selectedGuildId || !name.trim() || create.isPending} onClick={() => create.mutate({ guildId: selectedGuildId, name, type: Number(type), topic: topic || undefined })}>{create.isPending ? "생성 중..." : "채널 생성"}</Button></CardContent></Card></div></ResourceShell>;
}

function MembersSection({ guilds, selectedGuildId, setSelectedGuildId, members, isLoading }: { guilds: Array<{ id: string; name: string }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; members: Array<{ user: { id: string; username: string; global_name?: string | null; avatar?: string | null }; nick?: string | null; roles: string[]; joined_at?: string }>; isLoading: boolean }) {
  return <ResourceShell guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId}><Card className="border-white/10 bg-white/[0.035]"><CardHeader className="flex-row items-center justify-between space-y-0"><div><CardTitle className="text-base text-white">최근 멤버</CardTitle><p className="mt-1 text-sm text-slate-500">현재 API 페이지에서 최대 50명을 표시합니다.</p></div><Badge className="border-cyan-400/20 bg-cyan-400/10 text-cyan-200">{members.length}명</Badge></CardHeader><CardContent><div className="overflow-x-auto"><table className="w-full min-w-[620px] text-left text-sm"><thead className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-500"><tr><th className="pb-3 font-medium">멤버</th><th className="pb-3 font-medium">닉네임</th><th className="pb-3 font-medium">역할 수</th><th className="pb-3 font-medium">가입일</th></tr></thead><tbody className="divide-y divide-white/[0.06]">{members.map((member) => <tr key={member.user.id}><td className="py-3"><div className="flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-xs text-slate-300">{(member.user.global_name || member.user.username).slice(0, 1).toUpperCase()}</div><div><p className="text-slate-200">{member.user.global_name || member.user.username}</p><p className="text-xs text-slate-500">@{member.user.username} · {member.user.id}</p></div></div></td><td className="py-3 text-slate-400">{member.nick || "—"}</td><td className="py-3 text-slate-400">{member.roles.length}</td><td className="py-3 text-xs text-slate-500">{formatDate(member.joined_at)}</td></tr>)}</tbody></table>{isLoading && <p className="py-8 text-center text-sm text-slate-500">멤버를 불러오는 중...</p>}{!isLoading && selectedGuildId && !members.length && <EmptyState text="표시할 멤버가 없습니다." />}</div></CardContent></Card></ResourceShell>;
}

function RolesSection({ guilds, selectedGuildId, setSelectedGuildId, roles, refresh }: { guilds: Array<{ id: string; name: string }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; roles: Array<{ id: string; name: string; color: number; position: number; managed: boolean; mentionable: boolean }>; refresh: () => void }) {
  const [name, setName] = useState(""); const [color, setColor] = useState("#7c3aed");
  const create = trpc.discord.createRole.useMutation({ onSuccess: () => { setName(""); refresh(); toast.success("역할을 생성했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  const remove = trpc.discord.deleteRole.useMutation({ onSuccess: () => { refresh(); toast.success("역할을 삭제했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  return <ResourceShell guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId}><div className="grid gap-5 xl:grid-cols-[1fr_360px]"><Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">역할 목록 <span className="ml-2 text-xs font-normal text-slate-500">{roles.length}개</span></CardTitle></CardHeader><CardContent className="space-y-2">{roles.sort((a, b) => b.position - a.position).map((role) => <div key={role.id} className="flex items-center gap-3 rounded-lg border border-white/[0.07] bg-black/10 p-3"><div className="h-3 w-3 rounded-full" style={{ backgroundColor: colorHex(role.color) }} /><div className="min-w-0"><p className="truncate text-sm text-slate-200">{role.name}</p><p className="text-xs text-slate-500">position {role.position} · {role.id}</p></div>{role.managed ? <Badge variant="outline" className="ml-auto border-white/10 text-[10px] text-slate-500">MANAGED</Badge> : <Button variant="ghost" size="icon" className="ml-auto h-8 w-8 text-slate-500 hover:bg-red-400/10 hover:text-red-300" onClick={() => window.confirm(`‘${role.name}’ 역할을 삭제할까요?`) && remove.mutate({ guildId: selectedGuildId, roleId: role.id })}><Trash2 className="h-4 w-4" /></Button>}</div>)}{selectedGuildId && !roles.length && <EmptyState text="역할이 없습니다." />}</CardContent></Card><Card className="border-violet-400/20 bg-violet-400/[0.04]"><CardHeader><CardTitle className="flex items-center gap-2 text-base text-white"><Plus className="h-4 w-4 text-violet-300" />새 역할</CardTitle></CardHeader><CardContent className="space-y-4"><label className="block text-xs text-slate-400">역할 이름<Input value={name} onChange={(event) => setName(event.target.value)} placeholder="Moderator" className="mt-2 border-white/10 bg-black/20 text-white" /></label><label className="block text-xs text-slate-400">색상<div className="mt-2 flex gap-2"><Input value={color} onChange={(event) => setColor(event.target.value)} className="border-white/10 bg-black/20 text-white" /><input type="color" value={color} onChange={(event) => setColor(event.target.value)} className="h-10 w-12 rounded-md border border-white/10 bg-transparent p-1" /></div></label><Button className="w-full bg-violet-500 hover:bg-violet-400" disabled={!selectedGuildId || !name.trim() || create.isPending} onClick={() => create.mutate({ guildId: selectedGuildId, name, color: Number.parseInt(color.replace("#", ""), 16) || 0 })}>{create.isPending ? "생성 중..." : "역할 생성"}</Button></CardContent></Card></div></ResourceShell>;
}

function MessagesSection({ guilds, selectedGuildId, setSelectedGuildId, textChannels, selectedChannelId, setSelectedChannelId, messages, refresh }: { guilds: Array<{ id: string; name: string }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; textChannels: Array<{ id: string; name: string; type: number }>; selectedChannelId: string; setSelectedChannelId: (value: string) => void; messages: Array<{ id: string; content: string; author: { id: string; username: string; avatar?: string | null }; timestamp: string; embeds: unknown[] }>; refresh: () => void }) {
  const [content, setContent] = useState(""); const [embedEnabled, setEmbedEnabled] = useState(false); const [title, setTitle] = useState(""); const [description, setDescription] = useState(""); const [color, setColor] = useState("#7c3aed"); const [url, setUrl] = useState("");
  const sendMessage = trpc.discord.sendMessage.useMutation({ onSuccess: () => { setContent(""); setTitle(""); setDescription(""); setUrl(""); refresh(); toast.success("메시지를 전송했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  const remove = trpc.discord.deleteMessage.useMutation({ onSuccess: () => { refresh(); toast.success("메시지를 삭제했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  return <ResourceShell guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId}><div className="mb-5 flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.035] p-4"><Hash className="h-4 w-4 text-violet-300" /><div className="w-full max-w-md"><SelectBox value={selectedChannelId} onChange={setSelectedChannelId}><option value="">채널 선택</option>{textChannels.map((channel) => <option key={channel.id} value={channel.id}>#{channel.name}</option>)}</SelectBox></div></div><div className="grid gap-5 xl:grid-cols-[1fr_390px]"><Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">최근 메시지</CardTitle></CardHeader><CardContent className="space-y-2">{messages.map((message) => <div key={message.id} className="group flex gap-3 rounded-lg border border-white/[0.06] bg-black/10 p-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-800 text-xs text-slate-300">{message.author.username.slice(0, 1).toUpperCase()}</div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><span className="text-sm font-medium text-slate-200">{message.author.username}</span><span className="text-xs text-slate-600">{formatDate(message.timestamp)}</span></div><p className="mt-1 whitespace-pre-wrap break-words text-sm text-slate-400">{message.content || (message.embeds.length ? "[ 임베드 ]" : "[ 내용 없음 ]")}</p></div><Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-slate-600 opacity-0 transition group-hover:opacity-100 hover:bg-red-400/10 hover:text-red-300" onClick={() => window.confirm("이 메시지를 삭제할까요?") && remove.mutate({ channelId: selectedChannelId, messageId: message.id })}><Trash2 className="h-4 w-4" /></Button></div>)}{selectedChannelId && !messages.length && <EmptyState text="메시지가 없습니다." />}</CardContent></Card><Card className="border-violet-400/20 bg-violet-400/[0.04]"><CardHeader className="flex-row items-center justify-between space-y-0"><CardTitle className="text-base text-white">메시지 작성</CardTitle><button type="button" onClick={() => setEmbedEnabled(!embedEnabled)} className={`rounded-full px-3 py-1 text-xs transition ${embedEnabled ? "bg-violet-400/20 text-violet-200" : "bg-white/5 text-slate-500"}`}>{embedEnabled ? "임베드 ON" : "임베드 OFF"}</button></CardHeader><CardContent className="space-y-3"><Textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="전송할 메시지" className="min-h-24 border-white/10 bg-black/20 text-white placeholder:text-slate-600" />{embedEnabled && <div className="space-y-3 rounded-lg border border-white/10 bg-black/20 p-3"><Input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="임베드 제목" className="border-white/10 bg-transparent text-white" /><Textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="임베드 설명" className="min-h-20 border-white/10 bg-transparent text-white" /><div className="grid grid-cols-2 gap-2"><Input value={color} onChange={(event) => setColor(event.target.value)} placeholder="#7c3aed" className="border-white/10 bg-transparent text-white" /><Input value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://... (선택)" className="border-white/10 bg-transparent text-white" /></div></div>}<div className="flex items-center justify-between text-xs text-slate-600"><span>최대 2,000자 · 봇 권한에 따라 실패할 수 있습니다.</span><span>{content.length}/2000</span></div><Button className="w-full bg-violet-500 hover:bg-violet-400" disabled={!selectedChannelId || (!content.trim() && !title.trim() && !description.trim()) || sendMessage.isPending} onClick={() => sendMessage.mutate({ channelId: selectedChannelId, content: content || undefined, embed: embedEnabled ? { title: title || undefined, description: description || undefined, color: Number.parseInt(color.replace("#", ""), 16) || undefined, url: url || undefined } : undefined })}>{sendMessage.isPending ? "전송 중..." : "메시지 전송"}</Button></CardContent></Card></div></ResourceShell>;
}

function WebhooksSection({ guilds, selectedGuildId, setSelectedGuildId, textChannels, selectedChannelId, setSelectedChannelId, webhooks, refresh }: { guilds: Array<{ id: string; name: string }>; selectedGuildId: string; setSelectedGuildId: (value: string) => void; textChannels: Array<{ id: string; name: string; type: number }>; selectedChannelId: string; setSelectedChannelId: (value: string) => void; webhooks: Array<{ id: string; name: string; type: number; channel_id: string; avatar?: string | null }>; refresh: () => void }) {
  const [name, setName] = useState("");
  const create = trpc.discord.createWebhook.useMutation({ onSuccess: () => { setName(""); refresh(); toast.success("웹훅을 생성했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  const remove = trpc.discord.deleteWebhook.useMutation({ onSuccess: () => { refresh(); toast.success("웹훅을 삭제했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  return <ResourceShell guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId}><div className="mb-5 flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.035] p-4"><Webhook className="h-4 w-4 text-violet-300" /><div className="w-full max-w-md"><SelectBox value={selectedChannelId} onChange={setSelectedChannelId}><option value="">채널 선택</option>{textChannels.map((channel) => <option key={channel.id} value={channel.id}>#{channel.name}</option>)}</SelectBox></div></div><div className="grid gap-5 xl:grid-cols-[1fr_360px]"><Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">연결된 웹훅 <span className="ml-2 text-xs font-normal text-slate-500">{webhooks.length}개</span></CardTitle></CardHeader><CardContent className="space-y-2">{webhooks.map((webhook) => <div key={webhook.id} className="flex items-center gap-3 rounded-lg border border-white/[0.07] bg-black/10 p-3"><Webhook className="h-4 w-4 text-cyan-300" /><div className="min-w-0"><p className="truncate text-sm text-slate-200">{webhook.name}</p><p className="text-xs text-slate-500">{webhook.id}</p></div><Button variant="ghost" size="icon" className="ml-auto h-8 w-8 text-slate-600 hover:bg-red-400/10 hover:text-red-300" onClick={() => window.confirm("이 웹훅을 삭제할까요?") && remove.mutate({ webhookId: webhook.id })}><Trash2 className="h-4 w-4" /></Button></div>)}{selectedChannelId && !webhooks.length && <EmptyState text="이 채널에 웹훅이 없습니다." />}</CardContent></Card><Card className="border-violet-400/20 bg-violet-400/[0.04]"><CardHeader><CardTitle className="flex items-center gap-2 text-base text-white"><Plus className="h-4 w-4 text-violet-300" />새 웹훅</CardTitle></CardHeader><CardContent className="space-y-4"><Input value={name} onChange={(event) => setName(event.target.value)} placeholder="Webhook 이름" className="border-white/10 bg-black/20 text-white" /><p className="text-xs leading-5 text-slate-500">생성된 웹훅의 민감한 토큰은 화면에 표시하지 않습니다.</p><Button className="w-full bg-violet-500 hover:bg-violet-400" disabled={!selectedChannelId || !name.trim() || create.isPending} onClick={() => create.mutate({ channelId: selectedChannelId, name })}>{create.isPending ? "생성 중..." : "웹훅 생성"}</Button></CardContent></Card></div></ResourceShell>;
}

function DmSection() {
  const [userId, setUserId] = useState(""); const [content, setContent] = useState("");
  const send = trpc.discord.dm.useMutation({ onSuccess: () => { setContent(""); toast.success("DM을 전송했습니다."); }, onError: (error) => toast.error(errorText(error)) });
  return <div className="grid gap-5 lg:grid-cols-[1fr_360px]"><Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">직접 메시지 작성</CardTitle><p className="text-sm text-slate-500">사용자 ID가 정확하고 봇이 해당 사용자에게 DM을 보낼 수 있어야 합니다.</p></CardHeader><CardContent className="space-y-4"><label className="block text-xs text-slate-400">Discord 사용자 ID<Input value={userId} onChange={(event) => setUserId(event.target.value)} placeholder="123456789012345678" className="mt-2 border-white/10 bg-black/20 text-white" /></label><label className="block text-xs text-slate-400">메시지<Textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="안녕하세요!" className="mt-2 min-h-32 border-white/10 bg-black/20 text-white" /></label><div className="flex justify-end text-xs text-slate-600">{content.length}/2000</div><Button className="w-full bg-violet-500 hover:bg-violet-400" disabled={!userId.trim() || !content.trim() || send.isPending} onClick={() => send.mutate({ userId, content })}><Send className="mr-2 h-4 w-4" />{send.isPending ? "전송 중..." : "DM 전송"}</Button></CardContent></Card><Card className="border-amber-400/20 bg-amber-400/[0.04]"><CardContent className="p-6"><AlertTriangle className="mb-4 h-5 w-5 text-amber-300" /><h3 className="font-medium text-white">DM 사용 전 확인</h3><ul className="mt-3 space-y-2 text-sm leading-6 text-slate-400"><li>• 상대방의 DM 설정에 따라 차단될 수 있습니다.</li><li>• 운영·공지 목적의 메시지만 보내세요.</li><li>• 모든 전송 시도는 감사 로그에 기록됩니다.</li></ul></CardContent></Card></div>;
}

function AuditSection({ logs }: { logs: Array<{ id: number; action: string; resourceType: string; resourceId?: string | null; summary: string; createdAt: Date }> }) {
  return <Card className="border-white/10 bg-white/[0.035]"><CardHeader><CardTitle className="text-base text-white">관리자 작업 기록</CardTitle><p className="text-sm text-slate-500">토큰 값과 메시지 본문은 기록하지 않습니다.</p></CardHeader><CardContent><div className="space-y-1">{logs.map((log) => <div key={log.id} className="flex flex-col gap-2 border-b border-white/[0.06] py-3 text-sm sm:flex-row sm:items-center"><Badge variant="outline" className="w-fit border-violet-400/20 text-violet-200">{log.action}</Badge><span className="text-slate-300">{log.summary}</span><span className="text-xs text-slate-600 sm:ml-auto">{formatDate(log.createdAt)}</span></div>)}{!logs.length && <EmptyState text="아직 기록된 작업이 없습니다." />}</div></CardContent></Card>;
}

export default function Home() {
  const [location] = useLocation();
  const section = getSection(location);
  const [selectedGuildId, setSelectedGuildId] = useState("");
  const [selectedChannelId, setSelectedChannelId] = useState("");
  const statusQuery = trpc.discord.status.useQuery();
  const connected = Boolean(statusQuery.data?.connected);
  const guildsQuery = trpc.discord.guilds.useQuery(undefined, { enabled: connected, retry: false });
  const guilds = guildsQuery.data ?? [];
  const channelsQuery = trpc.discord.channels.useQuery({ guildId: selectedGuildId }, { enabled: connected && Boolean(selectedGuildId), retry: false });
  const channels = channelsQuery.data ?? [];
  const textChannels = useMemo(() => channels.filter((channel) => channel.type === 0 || channel.type === 5), [channels]);
  const membersQuery = trpc.discord.members.useQuery({ guildId: selectedGuildId, limit: 50 }, { enabled: section === "members" && connected && Boolean(selectedGuildId), retry: false });
  const rolesQuery = trpc.discord.roles.useQuery({ guildId: selectedGuildId }, { enabled: section === "roles" && connected && Boolean(selectedGuildId), retry: false });
  const messagesQuery = trpc.discord.messages.useQuery({ channelId: selectedChannelId }, { enabled: section === "messages" && connected && Boolean(selectedChannelId), retry: false });
  const webhooksQuery = trpc.discord.webhooks.useQuery({ channelId: selectedChannelId }, { enabled: section === "webhooks" && connected && Boolean(selectedChannelId), retry: false });
  const auditQuery = trpc.discord.audit.useQuery({ limit: 50 }, { enabled: section === "audit" && connected, retry: false });

  useEffect(() => { if (guilds[0] && !guilds.some((guild) => guild.id === selectedGuildId)) setSelectedGuildId(guilds[0].id); }, [guilds, selectedGuildId]);
  useEffect(() => { if (textChannels[0] && !textChannels.some((channel) => channel.id === selectedChannelId)) setSelectedChannelId(textChannels[0].id); }, [textChannels, selectedChannelId]);
  useEffect(() => { const firstError = [guildsQuery.error, channelsQuery.error, membersQuery.error, rolesQuery.error, messagesQuery.error, webhooksQuery.error, auditQuery.error].find(Boolean); if (firstError) toast.error(errorText(firstError)); }, [guildsQuery.error, channelsQuery.error, membersQuery.error, rolesQuery.error, messagesQuery.error, webhooksQuery.error, auditQuery.error]);

  const refresh = () => { void statusQuery.refetch(); void guildsQuery.refetch(); void channelsQuery.refetch(); void membersQuery.refetch(); void rolesQuery.refetch(); void messagesQuery.refetch(); void webhooksQuery.refetch(); void auditQuery.refetch(); };
  const meta = sectionMeta[section] || sectionMeta.overview;
  return <div className="min-h-[calc(100vh-2rem)] bg-[radial-gradient(circle_at_top_right,rgba(124,58,237,0.12),transparent_34%),radial-gradient(circle_at_bottom_left,rgba(8,145,178,0.08),transparent_32%)]"><div className="mx-auto max-w-[1440px] space-y-7 px-1 py-2 md:px-4"><SectionHeader section={section} connected={connected} />{!connected && section !== "overview" ? <div className="flex min-h-96 flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/[0.02] px-6 text-center"><LockKeyhole className="mb-4 h-8 w-8 text-violet-300" /><h2 className="text-lg font-medium text-white">먼저 봇을 연결하세요</h2><p className="mt-2 max-w-md text-sm text-slate-500">개요 화면에서 Discord Bot Token을 연결하면 서버·채널·멤버 관리 기능을 사용할 수 있습니다.</p></div> : section === "overview" ? <Overview guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} connected={connected} onRefresh={refresh} /> : section === "channels" ? <ChannelsSection guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} channels={channels} refresh={() => void channelsQuery.refetch()} /> : section === "members" ? <MembersSection guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} members={membersQuery.data ?? []} isLoading={membersQuery.isLoading} /> : section === "roles" ? <RolesSection guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} roles={rolesQuery.data ?? []} refresh={() => void rolesQuery.refetch()} /> : section === "messages" ? <MessagesSection guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} textChannels={textChannels} selectedChannelId={selectedChannelId} setSelectedChannelId={setSelectedChannelId} messages={messagesQuery.data ?? []} refresh={() => void messagesQuery.refetch()} /> : section === "webhooks" ? <WebhooksSection guilds={guilds} selectedGuildId={selectedGuildId} setSelectedGuildId={setSelectedGuildId} textChannels={textChannels} selectedChannelId={selectedChannelId} setSelectedChannelId={setSelectedChannelId} webhooks={webhooksQuery.data ?? []} refresh={() => void webhooksQuery.refetch()} /> : section === "dm" ? <DmSection /> : <AuditSection logs={auditQuery.data ?? []} />}</div></div>;
}
