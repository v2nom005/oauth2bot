import crypto from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { botConnections, auditLogs } from "../drizzle/schema";
import { getDb } from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const DISCORD_API = "https://discord.com/api/v10";
const MAX_MESSAGE_LENGTH = 2000;

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new Error("관리자 권한이 필요합니다.");
  }
  return next();
});

function encryptionKey() {
  return crypto.createHash("sha256").update(process.env.JWT_SECRET || "discord-control-center").digest();
}

function encryptToken(token: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(token, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString("base64url"), tag.toString("base64url"), encrypted.toString("base64url")].join(".");
}

function decryptToken(payload: string) {
  const [ivText, tagText, encryptedText] = payload.split(".");
  if (!ivText || !tagText || !encryptedText) throw new Error("저장된 연결 정보를 해석할 수 없습니다.");
  const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivText, "base64url"));
  decipher.setAuthTag(Buffer.from(tagText, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(encryptedText, "base64url")), decipher.final()]).toString("utf8");
}

async function discordRequest<T>(token: string, path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${DISCORD_API}${path}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
      ...(init.headers || {}),
    },
  });
  const text = await response.text();
  let body: unknown = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  if (!response.ok) {
    const retryAfter = response.headers.get("retry-after");
    const detail = typeof body === "object" && body && "message" in body ? String((body as { message: unknown }).message) : `Discord HTTP ${response.status}`;
    throw new Error(retryAfter ? `${detail} · ${retryAfter}초 후 재시도` : detail);
  }
  return body as T;
}

async function connectionFor(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("데이터베이스를 사용할 수 없습니다.");
  const row = await db.select().from(botConnections).where(eq(botConnections.userId, userId)).limit(1);
  if (!row[0]) throw new Error("먼저 봇 토큰을 연결하세요.");
  return { row: row[0], token: decryptToken(row[0].tokenEncrypted) };
}

async function writeAudit(userId: number, action: string, resourceType: string, summary: string, resourceId?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({ userId, action, resourceType, resourceId, summary });
}

const id = z.string().min(1).max(64);
const guildInput = z.object({ guildId: id });
const channelInput = z.object({ channelId: id });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  discord: router({
    status: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { connected: false as const };
      const row = await db.select({ id: botConnections.id, botUserId: botConnections.botUserId, botUsername: botConnections.botUsername, botAvatar: botConnections.botAvatar, updatedAt: botConnections.updatedAt }).from(botConnections).where(eq(botConnections.userId, ctx.user.id)).limit(1);
      return row[0] ? { connected: true as const, ...row[0] } : { connected: false as const };
    }),
    connect: adminProcedure.input(z.object({ token: z.string().trim().min(20).max(300) })).mutation(async ({ ctx, input }) => {
      const me = await discordRequest<{ id: string; username: string; avatar?: string | null }>(input.token, "/users/@me");
      const db = await getDb();
      if (!db) throw new Error("데이터베이스를 사용할 수 없습니다.");
      const tokenEncrypted = encryptToken(input.token);
      const existing = await db.select({ id: botConnections.id }).from(botConnections).where(eq(botConnections.userId, ctx.user.id)).limit(1);
      if (existing[0]) {
        await db.update(botConnections).set({ tokenEncrypted, botUserId: me.id, botUsername: me.username, botAvatar: me.avatar || null, updatedAt: new Date() }).where(eq(botConnections.id, existing[0].id));
      } else {
        await db.insert(botConnections).values({ userId: ctx.user.id, tokenEncrypted, botUserId: me.id, botUsername: me.username, botAvatar: me.avatar || null });
      }
      await writeAudit(ctx.user.id, "connect", "bot", `연결: ${me.username}`, me.id);
      return { connected: true as const, botUserId: me.id, botUsername: me.username, botAvatar: me.avatar || null };
    }),
    disconnect: adminProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("데이터베이스를 사용할 수 없습니다.");
      await db.delete(botConnections).where(eq(botConnections.userId, ctx.user.id));
      await writeAudit(ctx.user.id, "disconnect", "bot", "봇 연결 해제");
      return { success: true as const };
    }),
    guilds: adminProcedure.query(async ({ ctx }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ id: string; name: string; icon?: string | null; owner?: boolean; permissions?: string }>>(token, "/users/@me/guilds");
    }),
    channels: adminProcedure.input(guildInput).query(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ id: string; name: string; type: number; parent_id?: string | null; position: number; topic?: string | null }>>(token, `/guilds/${input.guildId}/channels`);
    }),
    members: adminProcedure.input(guildInput.extend({ limit: z.number().int().min(1).max(100).default(50) })).query(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ user: { id: string; username: string; global_name?: string | null; avatar?: string | null }; nick?: string | null; roles: string[]; joined_at?: string }>>(token, `/guilds/${input.guildId}/members?limit=${input.limit}`);
    }),
    roles: adminProcedure.input(guildInput).query(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ id: string; name: string; color: number; position: number; managed: boolean; mentionable: boolean }>>(token, `/guilds/${input.guildId}/roles`);
    }),
    createRole: adminProcedure.input(guildInput.extend({ name: z.string().trim().min(1).max(100), color: z.number().int().min(0).max(16777215).default(0), hoist: z.boolean().default(false), mentionable: z.boolean().default(false) })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      const result = await discordRequest<{ id: string; name: string }>(token, `/guilds/${input.guildId}/roles`, { method: "POST", body: JSON.stringify({ name: input.name, color: input.color, hoist: input.hoist, mentionable: input.mentionable }) });
      await writeAudit(ctx.user.id, "create", "role", `역할 생성: ${input.name}`, result.id);
      return result;
    }),
    deleteRole: adminProcedure.input(guildInput.extend({ roleId: id })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      await discordRequest<null>(token, `/guilds/${input.guildId}/roles/${input.roleId}`, { method: "DELETE" });
      await writeAudit(ctx.user.id, "delete", "role", "역할 삭제", input.roleId);
      return { success: true as const };
    }),
    createChannel: adminProcedure.input(guildInput.extend({ name: z.string().trim().min(1).max(100), type: z.number().int().min(0).max(15).default(0), topic: z.string().max(1024).optional() })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      const result = await discordRequest<{ id: string; name: string }>(token, `/guilds/${input.guildId}/channels`, { method: "POST", body: JSON.stringify({ name: input.name, type: input.type, topic: input.topic || undefined }) });
      await writeAudit(ctx.user.id, "create", "channel", `채널 생성: ${input.name}`, result.id);
      return result;
    }),
    messages: adminProcedure.input(channelInput).query(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ id: string; content: string; author: { id: string; username: string; avatar?: string | null }; timestamp: string; embeds: unknown[] }>>(token, `/channels/${input.channelId}/messages?limit=50`);
    }),
    sendMessage: adminProcedure.input(channelInput.extend({ content: z.string().max(MAX_MESSAGE_LENGTH).optional(), embed: z.object({ title: z.string().max(256).optional(), description: z.string().max(4096).optional(), color: z.number().int().min(0).max(16777215).optional(), url: z.string().url().max(2048).optional() }).optional() })).mutation(async ({ ctx, input }) => {
      if (!input.content?.trim() && !input.embed?.title && !input.embed?.description) throw new Error("메시지 내용이나 임베드 내용을 입력하세요.");
      const { token } = await connectionFor(ctx.user.id);
      const result = await discordRequest<{ id: string }>(token, `/channels/${input.channelId}/messages`, { method: "POST", body: JSON.stringify({ content: input.content?.trim() || undefined, embeds: input.embed ? [input.embed] : undefined }) });
      await writeAudit(ctx.user.id, "send", "message", "메시지 전송", input.channelId);
      return result;
    }),
    deleteMessage: adminProcedure.input(channelInput.extend({ messageId: id })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      await discordRequest<null>(token, `/channels/${input.channelId}/messages/${input.messageId}`, { method: "DELETE" });
      await writeAudit(ctx.user.id, "delete", "message", "메시지 삭제", input.messageId);
      return { success: true as const };
    }),
    webhooks: adminProcedure.input(channelInput).query(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      return discordRequest<Array<{ id: string; name: string; type: number; channel_id: string; avatar?: string | null }>>(token, `/channels/${input.channelId}/webhooks`);
    }),
    createWebhook: adminProcedure.input(channelInput.extend({ name: z.string().trim().min(1).max(80) })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      const result = await discordRequest<{ id: string; name: string; token?: string }>(token, `/channels/${input.channelId}/webhooks`, { method: "POST", body: JSON.stringify({ name: input.name }) });
      await writeAudit(ctx.user.id, "create", "webhook", `웹훅 생성: ${input.name}`, result.id);
      return result;
    }),
    deleteWebhook: adminProcedure.input(z.object({ webhookId: id })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      await discordRequest<null>(token, `/webhooks/${input.webhookId}`, { method: "DELETE" });
      await writeAudit(ctx.user.id, "delete", "webhook", "웹훅 삭제", input.webhookId);
      return { success: true as const };
    }),
    dm: adminProcedure.input(z.object({ userId: id, content: z.string().trim().min(1).max(MAX_MESSAGE_LENGTH) })).mutation(async ({ ctx, input }) => {
      const { token } = await connectionFor(ctx.user.id);
      const channel = await discordRequest<{ id: string }>(token, "/users/@me/channels", { method: "POST", body: JSON.stringify({ recipient_id: input.userId }) });
      const result = await discordRequest<{ id: string }>(token, `/channels/${channel.id}/messages`, { method: "POST", body: JSON.stringify({ content: input.content }) });
      await writeAudit(ctx.user.id, "send", "dm", `DM 전송: ${input.userId}`, result.id);
      return result;
    }),
    audit: adminProcedure.input(z.object({ limit: z.number().int().min(1).max(100).default(50) })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(auditLogs).where(eq(auditLogs.userId, ctx.user.id)).orderBy(desc(auditLogs.createdAt)).limit(input.limit);
    }),
  }),
});

export type AppRouter = typeof appRouter;
