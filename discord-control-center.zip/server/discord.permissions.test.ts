import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function contextFor(role: "admin" | "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: role === "admin" ? 1 : 2,
    openId: `${role}-sample`,
    email: `${role}@example.com`,
    name: role,
    loginMethod: "test",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("discord access control", () => {
  it("rejects non-admin users before reading bot credentials", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.discord.status()).rejects.toThrow("관리자 권한이 필요합니다.");
  });

  it("allows an admin to reach the status procedure", async () => {
    const caller = appRouter.createCaller(contextFor("admin"));
    const result = await caller.discord.status();
    expect(result).toHaveProperty("connected");
  });
});
