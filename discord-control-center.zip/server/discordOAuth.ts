import crypto from "node:crypto";
import type { Express, Request, Response } from "express";

const AUTHORIZE_URL = "https://discord.com/oauth2/authorize";
const TOKEN_URL = "https://discord.com/api/v10/oauth2/token";
const COOKIE_NAME = "discord_oauth_state";

function redirectUri(req: Request) {
  if (process.env.DISCORD_REDIRECT_URI) return process.env.DISCORD_REDIRECT_URI;
  const forwardedProto = req.headers["x-forwarded-proto"];
  const protocol = typeof forwardedProto === "string" ? forwardedProto.split(",")[0] : req.protocol;
  return `${protocol}://${req.get("host")}/api/auth/discord/callback`;
}

function sameSecret(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function readCookie(req: Request, name: string) {
  const header = req.headers.cookie || "";
  const entry = header.split(";").map(part => part.trim()).find(part => part.startsWith(`${name}=`));
  return entry ? decodeURIComponent(entry.slice(name.length + 1)) : undefined;
}

export function registerDiscordOAuthRoutes(app: Express) {
  app.get("/api/auth/discord/install", (req: Request, res: Response) => {
    const clientId = process.env.DISCORD_CLIENT_ID;
    if (!clientId) {
      res.status(503).send("Discord OAuth2 Client ID가 설정되지 않았습니다.");
      return;
    }

    const state = crypto.randomBytes(24).toString("hex");
    res.cookie(COOKIE_NAME, state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 10 * 60 * 1000,
      path: "/",
    });

    const url = new URL(AUTHORIZE_URL);
    url.searchParams.set("client_id", clientId);
    url.searchParams.set("scope", "identify guilds bot applications.commands");
    url.searchParams.set("response_type", "code");
    url.searchParams.set("redirect_uri", redirectUri(req));
    // The installer can change this in the Developer Portal or env without a code change.
    url.searchParams.set("permissions", process.env.DISCORD_BOT_PERMISSIONS || "8");
    res.redirect(url.toString());
  });

  app.get("/api/auth/discord/callback", async (req: Request, res: Response) => {
    const state = typeof req.query.state === "string" ? req.query.state : "";
    const storedState = readCookie(req, COOKIE_NAME);
    const code = typeof req.query.code === "string" ? req.query.code : "";
    res.clearCookie(COOKIE_NAME, { path: "/" });

    if (!state || !storedState || !sameSecret(state, storedState)) {
      res.status(400).send("OAuth2 state 검증에 실패했습니다. 다시 시도하세요.");
      return;
    }
    if (!code) {
      res.redirect("/?discord_oauth=cancelled");
      return;
    }

    const clientId = process.env.DISCORD_CLIENT_ID;
    const clientSecret = process.env.DISCORD_CLIENT_SECRET;
    if (!clientId || !clientSecret) {
      res.status(503).send("Discord OAuth2 시크릿이 설정되지 않았습니다.");
      return;
    }

    try {
      const tokenResponse = await fetch(TOKEN_URL, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri(req),
        }),
      });
      if (!tokenResponse.ok) {
        res.redirect("/?discord_oauth=failed");
        return;
      }
      // OAuth2 access tokens are intentionally not persisted. The bot token remains a separate, encrypted server-side credential.
      await tokenResponse.json();
      res.redirect("/?discord_oauth=success");
    } catch {
      res.redirect("/?discord_oauth=failed");
    }
  });
}
