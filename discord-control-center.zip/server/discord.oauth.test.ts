import { describe, expect, it } from "vitest";

describe("Discord OAuth2 configuration", () => {
  it("recognizes the configured client credentials without issuing a token", async () => {
    const clientId = process.env.DISCORD_CLIENT_ID;
    const clientSecret = process.env.DISCORD_CLIENT_SECRET;
    expect(clientId).toBeTruthy();
    expect(clientSecret).toBeTruthy();

    const response = await fetch("https://discord.com/api/v10/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId!,
        client_secret: clientSecret!,
        grant_type: "authorization_code",
        code: "dcc-invalid-test-code",
        redirect_uri: process.env.DISCORD_REDIRECT_URI || "http://localhost:3000/api/auth/discord/callback",
      }),
    });
    const body = await response.json() as { error?: string };
    expect(response.status).toBe(400);
    expect(body.error).not.toBe("invalid_client");
  }, 15000);
});
